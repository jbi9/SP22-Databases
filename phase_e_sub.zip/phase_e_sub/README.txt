Joanna Bi jbi9
Udochukwu Nwosu unwosu6

No feedback from CA mentor or instructor given

Made minor edits to the queries. 

